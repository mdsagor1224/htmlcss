(function ($) {
	"use strict";

    jQuery(document).ready(function($){


       $(".hompage-slide").owlCarousel({
           items: 1,
           loop: true,
           nav: false,
           dots: true,
           autoplay: false,
       });


        
         $(".logo-carousel").owlCarousel({
           items: 5,
           loop: true,
           nav: false,
           dots: true,
           autoplay: false,
       });


    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	